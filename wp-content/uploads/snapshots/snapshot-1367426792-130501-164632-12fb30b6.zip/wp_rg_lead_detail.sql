CREATE TABLE IF NOT EXISTS `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_lead_detail`;
 
INSERT INTO `wp_rg_lead_detail` VALUES ('1', '1', '1', '1.3', 'Test'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('2', '1', '1', '1.6', 'Test'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('3', '1', '1', '2', '(123)123-1234'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('4', '1', '1', '5', 'boo!'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('5', '2', '1', '1.3', 'Robert'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('6', '2', '1', '1.6', 'DiGioai'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('7', '2', '1', '7', 'Acquintiy'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('8', '2', '1', '2', '1231231234'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('9', '2', '1', '3', 'robertd@acquinity.com'); 
INSERT INTO `wp_rg_lead_detail` VALUES ('10', '2', '1', '5', 'test\r\n');
# --------------------------------------------------------

