CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_taxonomy`;
 
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'nav_menu', '', '0', '7'); 
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'nav_menu', '', '0', '20'); 
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('6', '6', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('7', '7', 'post_tag', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('8', '8', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('9', '9', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('10', '10', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('11', '11', 'post_tag', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('12', '12', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('13', '13', 'category', '', '0', '1'); 
INSERT INTO `wp_term_taxonomy` VALUES ('14', '14', 'nav_menu', '', '0', '5');
# --------------------------------------------------------

