CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_usermeta`;
 
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'lkbgift'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '0'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '1121'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'nav_menu_recently_edited', '14'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'wp_user-settings', 'editor=html&hidetb=1&libraryContent=browse&mfold=f'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'wp_user-settings-time', '1366058517'); 
INSERT INTO `wp_usermeta` VALUES ('20', '1', 'closedpostboxes_case-study', 'a:1:{i:0;s:11:"commentsdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('21', '1', 'metaboxhidden_case-study', 'a:5:{i:0;s:7:"acf_207";i:1;s:7:"acf_203";i:2;s:6:"acf_54";i:3;s:6:"acf_68";i:4;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('22', '1', 'closedpostboxes_dashboard', 'a:1:{i:0;s:17:"dashboard_plugins";}'); 
INSERT INTO `wp_usermeta` VALUES ('23', '1', 'metaboxhidden_dashboard', 'a:9:{i:0;s:19:"dashboard_right_now";i:1;s:25:"dashboard_recent_comments";i:2;s:24:"dashboard_incoming_links";i:3;s:17:"dashboard_plugins";i:4;s:18:"rg_forms_dashboard";i:5;s:21:"dashboard_quick_press";i:6;s:23:"dashboard_recent_drafts";i:7;s:17:"dashboard_primary";i:8;s:19:"dashboard_secondary";}'); 
INSERT INTO `wp_usermeta` VALUES ('24', '1', 'wp_yarpp_saw_optin', '1'); 
INSERT INTO `wp_usermeta` VALUES ('25', '1', 'closedpostboxes_success-story', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('26', '1', 'metaboxhidden_success-story', 'a:5:{i:0;s:7:"acf_207";i:1;s:7:"acf_203";i:2;s:6:"acf_54";i:3;s:6:"acf_68";i:4;s:7:"slugdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('27', '2', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('28', '2', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('29', '2', 'nickname', 'mikemcc'); 
INSERT INTO `wp_usermeta` VALUES ('30', '2', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('31', '2', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('32', '2', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('33', '2', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('34', '2', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('35', '2', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('36', '2', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('37', '2', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('38', '2', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('39', '3', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('40', '3', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('41', '3', 'nickname', 'RobertD'); 
INSERT INTO `wp_usermeta` VALUES ('42', '3', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('43', '3', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('44', '3', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('45', '3', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('46', '3', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('47', '3', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('48', '3', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('49', '3', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('50', '3', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'); 
INSERT INTO `wp_usermeta` VALUES ('51', '3', 'wp_dashboard_quick_press_last_post_id', '803'); 
INSERT INTO `wp_usermeta` VALUES ('52', '3', 'wp_user-settings', 'libraryContent=browse&editor=tinymce'); 
INSERT INTO `wp_usermeta` VALUES ('53', '3', 'wp_user-settings-time', '1366128736'); 
INSERT INTO `wp_usermeta` VALUES ('54', '2', 'wp_dashboard_quick_press_last_post_id', '784'); 
INSERT INTO `wp_usermeta` VALUES ('55', '2', 'wp_user-settings', 'libraryContent=browse&align=left&imgsize=full&editor=tinymce&ed_size=614'); 
INSERT INTO `wp_usermeta` VALUES ('56', '2', 'wp_user-settings-time', '1366130302'); 
INSERT INTO `wp_usermeta` VALUES ('57', '2', 'nav_menu_recently_edited', '3'); 
INSERT INTO `wp_usermeta` VALUES ('58', '2', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('59', '2', 'metaboxhidden_nav-menus', 'a:6:{i:0;s:8:"add-post";i:1;s:17:"add-success-story";i:2;s:15:"add-testimonial";i:3;s:23:"add-testimonials-widget";i:4;s:12:"add-post_tag";i:5;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('60', '1', 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:122:"dashboard_right_now,dashboard_recent_comments,dashboard_incoming_links,dashboard_plugins,rg_forms_dashboard,ga-dash-widget";s:4:"side";s:83:"dashboard_quick_press,dashboard_recent_drafts,dashboard_primary,dashboard_secondary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('61', '1', 'screen_layout_dashboard', '1'); 
INSERT INTO `wp_usermeta` VALUES ('62', '3', 'nav_menu_recently_edited', '3'); 
INSERT INTO `wp_usermeta` VALUES ('63', '3', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('64', '3', 'metaboxhidden_nav-menus', 'a:6:{i:0;s:8:"add-post";i:1;s:17:"add-success-story";i:2;s:15:"add-testimonial";i:3;s:23:"add-testimonials-widget";i:4;s:12:"add-post_tag";i:5;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('65', '2', 'wp_yarpp_saw_optin', '1'); 
INSERT INTO `wp_usermeta` VALUES ('66', '3', 'wp_yarpp_saw_optin', '1'); 
INSERT INTO `wp_usermeta` VALUES ('67', '2', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('68', '2', 'metaboxhidden_page', 'a:15:{i:0;s:6:"acf_68";i:1;s:7:"acf_844";i:2;s:7:"acf_550";i:3;s:7:"acf_203";i:4;s:6:"acf_54";i:5;s:7:"acf_578";i:6;s:7:"acf_575";i:7;s:7:"acf_576";i:8;s:7:"acf_577";i:9;s:7:"acf_574";i:10;s:10:"postcustom";i:11;s:16:"commentstatusdiv";i:12;s:11:"commentsdiv";i:13;s:7:"slugdiv";i:14;s:9:"authordiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('69', '1', 'show_per_page', '25'); 
INSERT INTO `wp_usermeta` VALUES ('70', '1', 'orderby', ''); 
INSERT INTO `wp_usermeta` VALUES ('71', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('72', '1', 'metaboxhidden_page', 'a:16:{i:0;s:7:"acf_550";i:1;s:7:"acf_203";i:2;s:6:"acf_54";i:3;s:6:"acf_68";i:4;s:7:"acf_418";i:5;s:7:"acf_578";i:6;s:7:"acf_575";i:7;s:7:"acf_576";i:8;s:7:"acf_577";i:9;s:7:"acf_574";i:10;s:10:"postcustom";i:11;s:16:"commentstatusdiv";i:12;s:11:"commentsdiv";i:13;s:7:"slugdiv";i:14;s:9:"authordiv";i:15;s:12:"revisionsdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('73', '1', 'meta-box-order_page', 'a:3:{s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:172:"acf_457,acf_550,acf_422,acf_203,acf_664,acf_54,acf_68,acf_418,acf_578,acf_575,acf_576,acf_577,acf_574,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv,revisionsdiv";s:8:"advanced";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('74', '1', 'screen_layout_page', '2'); 
INSERT INTO `wp_usermeta` VALUES ('75', '2', 'closedpostboxes_dashboard', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('76', '2', 'metaboxhidden_dashboard', 'a:9:{i:0;s:19:"dashboard_right_now";i:1;s:25:"dashboard_recent_comments";i:2;s:24:"dashboard_incoming_links";i:3;s:17:"dashboard_plugins";i:4;s:18:"rg_forms_dashboard";i:5;s:21:"dashboard_quick_press";i:6;s:23:"dashboard_recent_drafts";i:7;s:17:"dashboard_primary";i:8;s:19:"dashboard_secondary";}'); 
INSERT INTO `wp_usermeta` VALUES ('77', '2', 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:122:"dashboard_right_now,dashboard_recent_comments,dashboard_incoming_links,dashboard_plugins,ga-dash-widget,rg_forms_dashboard";s:4:"side";s:83:"dashboard_quick_press,dashboard_recent_drafts,dashboard_primary,dashboard_secondary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('78', '2', 'screen_layout_dashboard', '1'); 
INSERT INTO `wp_usermeta` VALUES ('79', '3', 'closedpostboxes_post', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('80', '3', 'metaboxhidden_post', 'a:18:{i:0;s:7:"acf_550";i:1;s:7:"acf_422";i:2;s:7:"acf_203";i:3;s:6:"acf_54";i:4;s:6:"acf_68";i:5;s:7:"acf_418";i:6;s:7:"acf_578";i:7;s:7:"acf_575";i:8;s:7:"acf_576";i:9;s:7:"acf_577";i:10;s:7:"acf_574";i:11;s:13:"trackbacksdiv";i:12;s:10:"postcustom";i:13;s:16:"commentstatusdiv";i:14;s:11:"commentsdiv";i:15;s:7:"slugdiv";i:16;s:9:"authordiv";i:17;s:12:"revisionsdiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('81', '2', 'rtladminbar', 'ltr'); 
INSERT INTO `wp_usermeta` VALUES ('94', '3', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('95', '3', 'metaboxhidden_page', 'a:16:{i:0;s:6:"acf_68";i:1;s:7:"acf_844";i:2;s:7:"acf_550";i:3;s:7:"acf_203";i:4;s:6:"acf_54";i:5;s:7:"acf_578";i:6;s:7:"acf_575";i:7;s:7:"acf_576";i:8;s:7:"acf_577";i:9;s:7:"acf_574";i:10;s:10:"postcustom";i:11;s:16:"commentstatusdiv";i:12;s:11:"commentsdiv";i:13;s:7:"slugdiv";i:14;s:9:"authordiv";i:15;s:12:"revisionsdiv";}');
# --------------------------------------------------------

