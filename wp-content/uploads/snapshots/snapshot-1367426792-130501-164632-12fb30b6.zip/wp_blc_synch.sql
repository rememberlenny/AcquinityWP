CREATE TABLE IF NOT EXISTS `wp_blc_synch` (
  `container_id` int(20) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL,
  `synched` tinyint(3) unsigned NOT NULL,
  `last_synch` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`container_type`,`container_id`),
  KEY `synched` (`synched`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_blc_synch`;
 
INSERT INTO `wp_blc_synch` VALUES ('5', 'page', '1', '2013-04-11 11:37:22'); 
INSERT INTO `wp_blc_synch` VALUES ('6', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('7', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('8', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('36', 'page', '1', '2013-04-10 14:43:58'); 
INSERT INTO `wp_blc_synch` VALUES ('96', 'page', '1', '2013-04-11 09:06:57'); 
INSERT INTO `wp_blc_synch` VALUES ('100', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('127', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('128', 'page', '1', '2013-04-10 14:43:58'); 
INSERT INTO `wp_blc_synch` VALUES ('129', 'page', '1', '2013-04-15 07:28:23'); 
INSERT INTO `wp_blc_synch` VALUES ('130', 'page', '1', '2013-04-15 07:28:23'); 
INSERT INTO `wp_blc_synch` VALUES ('143', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('469', 'page', '1', '2013-04-11 11:37:22'); 
INSERT INTO `wp_blc_synch` VALUES ('619', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('620', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('621', 'page', '1', '2013-04-16 16:41:56'); 
INSERT INTO `wp_blc_synch` VALUES ('622', 'page', '1', '2013-04-17 14:56:33'); 
INSERT INTO `wp_blc_synch` VALUES ('654', 'page', '1', '2013-04-11 13:17:41'); 
INSERT INTO `wp_blc_synch` VALUES ('319', 'post', '1', '2013-04-15 20:48:08'); 
INSERT INTO `wp_blc_synch` VALUES ('330', 'post', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('804', 'post', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('846', 'post', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('948', 'page', '1', '2013-04-10 08:18:42'); 
INSERT INTO `wp_blc_synch` VALUES ('1004', 'page', '1', '2013-04-16 21:17:10');
# --------------------------------------------------------

