CREATE TABLE IF NOT EXISTS `wp_blc_instances` (
  `instance_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` int(10) unsigned NOT NULL,
  `container_id` int(10) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL DEFAULT 'post',
  `link_text` varchar(250) NOT NULL DEFAULT '',
  `parser_type` varchar(40) NOT NULL DEFAULT 'link',
  `container_field` varchar(250) NOT NULL DEFAULT '',
  `link_context` varchar(250) NOT NULL DEFAULT '',
  `raw_url` text NOT NULL,
  PRIMARY KEY (`instance_id`),
  KEY `link_id` (`link_id`),
  KEY `source_id` (`container_type`,`container_id`),
  KEY `parser_type` (`parser_type`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_blc_instances`;
 
INSERT INTO `wp_blc_instances` VALUES ('27', '23', '96', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Content_Creation_Curation_041013.png'); 
INSERT INTO `wp_blc_instances` VALUES ('2', '2', '100', 'page', '', 'link', 'post_content', '', 'http://www.political.com'); 
INSERT INTO `wp_blc_instances` VALUES ('3', '3', '100', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Political_Narrow_040813.png'); 
INSERT INTO `wp_blc_instances` VALUES ('4', '4', '127', 'page', '', 'link', 'post_content', '', 'http://www.sweepstakes.com'); 
INSERT INTO `wp_blc_instances` VALUES ('5', '5', '127', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Sweepstakes_032213.png'); 
INSERT INTO `wp_blc_instances` VALUES ('23', '6', '128', 'page', '', 'link', 'post_content', '', 'http://www.bsaving.com'); 
INSERT INTO `wp_blc_instances` VALUES ('24', '7', '128', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Bsaving_Narrow_040813.png'); 
INSERT INTO `wp_blc_instances` VALUES ('41', '9', '129', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Health_Professor_032213.png'); 
INSERT INTO `wp_blc_instances` VALUES ('36', '13', '469', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Greg_Van_Horn_BW4.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('37', '14', '469', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/David_Hatton_BW4.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('35', '12', '469', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Scott_Modist_BW4.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('34', '11', '469', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Bob_Hayes_BW4.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('33', '10', '469', 'page', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/03/Garry_Jonas_BW4.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('15', '15', '804', 'post', 'Random state-of-digital-media stats', 'link', 'post_content', '', 'http://bit.ly/11OS5ce'); 
INSERT INTO `wp_blc_instances` VALUES ('16', '16', '804', 'post', 'Infographic...marketing, art and science', 'link', 'post_content', '', 'http://bit.ly/14Jk9hM'); 
INSERT INTO `wp_blc_instances` VALUES ('17', '17', '804', 'post', 'Flash-sale retailers and social', 'link', 'post_content', '', 'http://bit.ly/10BKesj'); 
INSERT INTO `wp_blc_instances` VALUES ('18', '18', '804', 'post', 'AYTM report...YouTube first, Facebook second for video', 'link', 'post_content', '', 'http://bit.ly/Y1DpQx'); 
INSERT INTO `wp_blc_instances` VALUES ('19', '19', '804', 'post', 'Video...6 ways brands judge tech providers', 'link', 'post_content', '', 'http://bit.ly/12nNkXn'); 
INSERT INTO `wp_blc_instances` VALUES ('20', '20', '804', 'post', 'Digital media rally Momentum1000', 'link', 'post_content', '', 'http://on.mash.to/10Aul6E'); 
INSERT INTO `wp_blc_instances` VALUES ('21', '21', '804', 'post', 'Digital health startup Asthmapolis', 'link', 'post_content', '', 'http://tcrn.ch/16w9fbA'); 
INSERT INTO `wp_blc_instances` VALUES ('22', '22', '804', 'post', 'Sackmann new CMO of Crocs', 'link', 'post_content', '', 'http://buswk.co/YAi7gv'); 
INSERT INTO `wp_blc_instances` VALUES ('40', '8', '129', 'page', '', 'link', 'post_content', '', 'http://healthprofessor.com'); 
INSERT INTO `wp_blc_instances` VALUES ('48', '24', '319', 'post', '', 'image', 'post_content', '', 'http://localhost:4421/wp-content/uploads/2013/04/Don_Silvestri_2x2.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('90', '27', '1004', 'page', 'Facebook.', 'link', 'post_content', '', 'http://www.Facebook.com/AcquinitySports'); 
INSERT INTO `wp_blc_instances` VALUES ('88', '25', '1004', 'page', 'AcquinitySports.com', 'link', 'post_content', '', 'http://www.AcquinitySports.com'); 
INSERT INTO `wp_blc_instances` VALUES ('89', '28', '1004', 'page', 'Twitter', 'link', 'post_content', '', 'http://www.twitter.com/acquinitysports'); 
INSERT INTO `wp_blc_instances` VALUES ('97', '29', '622', 'page', 'Partners', 'link', 'post_content', '', 'http://localhost:4421/partners/'); 
INSERT INTO `wp_blc_instances` VALUES ('98', '30', '622', 'page', 'Success Stories', 'link', 'post_content', '', 'http://localhost:4421/success-story/');
# --------------------------------------------------------

