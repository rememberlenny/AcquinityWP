CREATE TABLE IF NOT EXISTS `wp_yarpp_related_cache` (
  `reference_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `score` float unsigned NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reference_ID`,`ID`),
  KEY `score` (`score`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_yarpp_related_cache`;
 
INSERT INTO `wp_yarpp_related_cache` VALUES ('5', '0', '0', '2013-04-02 10:31:42'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('6', '0', '0', '2013-04-02 09:22:49'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('7', '0', '0', '2013-04-02 10:04:45'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('8', '0', '0', '2013-04-02 08:47:27'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('36', '0', '0', '2013-04-02 07:32:26'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('94', '0', '0', '2013-04-02 08:49:41'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('95', '0', '0', '2013-04-02 08:40:16'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('96', '0', '0', '2013-04-02 10:24:30'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('100', '0', '0', '2013-04-02 10:08:02'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('127', '0', '0', '2013-04-02 10:05:01'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('128', '0', '0', '2013-04-02 10:05:32'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('129', '0', '0', '2013-04-02 10:06:27'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('130', '0', '0', '2013-04-02 07:28:50'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('143', '0', '0', '2013-04-02 10:21:00'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('319', '0', '0', '2013-04-01 15:00:37'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('330', '0', '0', '2013-04-02 10:51:22'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('465', '0', '0', '2013-04-01 15:18:21'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('466', '0', '0', '2013-04-01 15:18:25'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('469', '0', '0', '2013-04-02 10:27:21'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('473', '0', '0', '2013-04-02 10:23:06'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('528', '0', '0', '2013-04-02 10:16:27'); 
INSERT INTO `wp_yarpp_related_cache` VALUES ('529', '0', '0', '2013-04-02 10:16:23');
# --------------------------------------------------------

