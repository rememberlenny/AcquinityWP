CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_term_relationships`;
 
INSERT INTO `wp_term_relationships` VALUES ('12', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('14', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('15', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('16', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('31', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('33', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('34', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('35', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('102', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('106', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('110', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('111', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('112', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('131', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('132', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('133', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('134', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('295', '8', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('296', '9', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('297', '10', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('319', '5', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('330', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('330', '11', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('344', '12', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('471', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('528', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('529', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('530', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('624', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('625', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('626', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('632', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('633', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('657', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('658', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('745', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('804', '6', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('846', '13', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('959', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1006', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1126', '14', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1129', '14', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1130', '14', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1131', '14', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1132', '14', '0');
# --------------------------------------------------------

