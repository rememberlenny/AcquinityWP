CREATE TABLE IF NOT EXISTS `wp_bpspro_seclog_ignore` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_agent_bot` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_bpspro_seclog_ignore`;

# --------------------------------------------------------

