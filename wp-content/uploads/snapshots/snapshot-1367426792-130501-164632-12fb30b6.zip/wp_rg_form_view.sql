CREATE TABLE IF NOT EXISTS `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_form_view`;
 
INSERT INTO `wp_rg_form_view` VALUES ('1', '1', '2013-03-22 17:01:38', '::1', '2'); 
INSERT INTO `wp_rg_form_view` VALUES ('2', '1', '2013-03-28 18:31:33', '108.162.209.37', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('3', '1', '2013-03-29 11:04:09', '66.249.74.234', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('4', '1', '2013-03-29 18:07:26', '66.249.73.203', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('5', '1', '2013-04-02 15:52:43', '108.6.178.61', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('6', '1', '2013-04-02 21:31:36', '38.104.94.198', '5'); 
INSERT INTO `wp_rg_form_view` VALUES ('7', '1', '2013-04-04 15:12:14', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('8', '1', '2013-04-05 15:55:26', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('9', '1', '2013-04-05 16:29:40', '23.22.110.11', '2'); 
INSERT INTO `wp_rg_form_view` VALUES ('10', '1', '2013-04-06 07:36:34', '108.162.209.45', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('11', '1', '2013-04-08 21:19:05', '54.235.59.156', '2'); 
INSERT INTO `wp_rg_form_view` VALUES ('12', '1', '2013-04-11 02:50:39', '68.175.88.127', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('13', '1', '2013-04-15 15:45:42', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('14', '1', '2013-04-15 16:17:25', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('15', '1', '2013-04-15 17:27:10', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('16', '1', '2013-04-15 20:07:12', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('17', '1', '2013-04-15 21:55:50', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('18', '1', '2013-04-16 13:32:55', '23.22.126.130', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('19', '1', '2013-04-17 19:49:42', '38.104.94.198', '4'); 
INSERT INTO `wp_rg_form_view` VALUES ('20', '1', '2013-04-17 21:12:06', '38.104.94.198', '4'); 
INSERT INTO `wp_rg_form_view` VALUES ('21', '1', '2013-04-17 22:06:44', '38.104.94.198', '1'); 
INSERT INTO `wp_rg_form_view` VALUES ('22', '1', '2013-04-30 15:24:35', '::1', '1');
# --------------------------------------------------------

