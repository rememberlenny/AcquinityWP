CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_terms`;
 
INSERT INTO `wp_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Parent-Links', 'parent-links', '0'); 
INSERT INTO `wp_terms` VALUES ('3', 'Full-Menu', 'full-menu', '0'); 
INSERT INTO `wp_terms` VALUES ('4', 'Press Release', 'press-release', '0'); 
INSERT INTO `wp_terms` VALUES ('5', 'Event Appearances', 'event-appearances', '0'); 
INSERT INTO `wp_terms` VALUES ('6', 'Industry News', 'industry-news', '0'); 
INSERT INTO `wp_terms` VALUES ('7', 'LEADSCON', 'leadscon', '0'); 
INSERT INTO `wp_terms` VALUES ('8', 'Energy', 'energy', '0'); 
INSERT INTO `wp_terms` VALUES ('9', 'Telecom', 'telecom', '0'); 
INSERT INTO `wp_terms` VALUES ('10', 'Retail', 'retail', '0'); 
INSERT INTO `wp_terms` VALUES ('11', 'bsavings', 'bsavings', '0'); 
INSERT INTO `wp_terms` VALUES ('12', 'Insurance', 'insurance', '0'); 
INSERT INTO `wp_terms` VALUES ('13', 'Blog', 'blog', '0'); 
INSERT INTO `wp_terms` VALUES ('14', 'Top parent', 'top-parent', '0');
# --------------------------------------------------------

