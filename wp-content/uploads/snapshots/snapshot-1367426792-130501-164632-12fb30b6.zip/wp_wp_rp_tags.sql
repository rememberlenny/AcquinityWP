CREATE TABLE IF NOT EXISTS `wp_wp_rp_tags` (
  `post_id` mediumint(9) DEFAULT NULL,
  `post_date` datetime NOT NULL,
  `label` varchar(32) NOT NULL,
  `weight` float DEFAULT NULL,
  KEY `post_id` (`post_id`),
  KEY `label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_wp_rp_tags`;
 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'C_event appearances', '5'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_freebi', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_vega', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_market', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_media', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_la', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_sale', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_affili', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_analyt', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_websit', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_monet', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_real', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_don', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_entri', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_space', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('319', '2013-03-27 14:03:22', 'A_properti', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('529', '2013-03-02 14:19:15', 'A_york', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('529', '2013-03-02 14:19:15', 'A_corpor', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('529', '2013-03-02 14:19:15', 'A_offic', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('529', '2013-03-02 14:19:15', 'A_open', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('528', '2013-02-02 14:14:40', 'A_websit', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('528', '2013-02-02 14:14:40', 'A_launch', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('36', '2013-03-20 20:00:45', 'A_home', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_coupon', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_sweepstak', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_health', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_polit', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_googl', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_web', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_insur', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_travel', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_market', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_entertain', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_telemarket', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_educ', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_onlin', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_facebook', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('7', '2013-03-20 15:34:58', 'A_advertis', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_health', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_market', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_insur', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_travel', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_entertain', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_educ', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_sale', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_telecom', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_deal', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_amp', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_stream', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_advertis', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_ai', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_monet', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('143', '2013-03-21 20:51:53', 'A_custom', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'P_bsavings', '10'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'C_press release', '5'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_mobil', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_livingsoci', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_social', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_market', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_shop', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_wireless', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_beach', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_van', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_deerfield', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_technolog', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_onlin', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_greg', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_sale', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_brand', '2'); 
INSERT INTO `wp_wp_rp_tags` VALUES ('330', '2013-03-27 14:44:58', 'A_ken', '2');
# --------------------------------------------------------

