CREATE TABLE IF NOT EXISTS `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_form`;
 
INSERT INTO `wp_rg_form` VALUES ('1', 'Contact Us', '2013-03-22 14:05:18', '1');
# --------------------------------------------------------

